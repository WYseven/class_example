/*
	主題設置：
		{
			theme: @value Sting  默认为"black"
		}

		theme的值为：
			red
			blue
*/

var theme = {
	theme:"blue"
}